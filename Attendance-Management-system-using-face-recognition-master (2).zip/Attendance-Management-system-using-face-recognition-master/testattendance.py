import tkinter as tk
from tkinter import ttk
from tkinter import *
from PIL import ImageTk, Image
import pyttsx3
import os
from functools import partial

# Set up the engine for text-to-speech
engine = pyttsx3.init()
engine.say("Welcome!")
engine.say("Please browse through your options..")
engine.runAndWait()


def on_select(event):
    selected_item = event.widget.get()
    print(f"Selected: {selected_item}")


def text_to_speech(user_text):
    engine = pyttsx3.init()
    engine.say(user_text)
    engine.runAndWait()


def set_background_image(window, image_path):
    # Open the image using PIL
    pil_image = Image.open(image_path)
    # Resize the image to fit the window
    pil_image = pil_image.resize((1280, 720), Image.ANTIALIAS)

    # Convert PIL image to PhotoImage
    tk_image = ImageTk.PhotoImage(pil_image)

    # Create a label to display the image
    bg_label = tk.Label(window, image=tk_image)
    bg_label.image = tk_image
    bg_label.place(relwidth=1, relheight=1)
    # Raise the label to the bottom of the stacking order
    bg_label.lower()


# Initialize the main window
window = Tk()
window.title("Face recognizer")
window.geometry("1280x720")

# Set background image
set_background_image(window,
                     "G:/Code 23-24/Mrunal/2/Attendance-Management-system-using-face-recognition-master/bgimg.jpg")


# Function to destroy secondary screen
def del_screen(screen):
    screen.destroy()


# Function to handle invalid input error message
def error_screen(message):
    error_window = tk.Tk()
    error_window.geometry("400x110")
    error_window.title("Warning!!")
    error_window.configure(background="blue")
    error_window.resizable(0, 0)
    tk.Label(
        error_window,
        text=message,
        fg="yellow",
        bg="black",
        font=("times", 20, " bold "),
    ).pack()
    tk.Button(
        error_window,
        text="OK",
        command=partial(del_screen, error_window),
        fg="yellow",
        bg="black",
        width=9,
        height=1,
        activebackground="Red",
        font=("times", 20, " bold "),
    ).place(x=110, y=50)


# Function to validate input
def validate_input(inStr, acttyp):
    if acttyp == "1":  # insert
        if not inStr.isdigit():
            return False
    return True


# Function to take image
def take_image():
    # Your code for taking image goes here
    pass


# Function to train image
def train_image():
    # Your code for training image goes here
    pass


# Register UI
def register_ui():
    register_window = Tk()
    register_window.title("Register a New Customer")
    register_window.geometry("980x580")
    register_window.configure(background="black")
    register_window.resizable(0, 0)
    titl = tk.Label(register_window, bg="black", relief=RIDGE, bd=10, font=("arial", 35))
    titl.pack(fill=X)
    titl = tk.Label(
        register_window, text="Register Your Face", bg="black", fg="green", font=("arial", 30),
    )
    titl.place(x=270, y=12)

    # Your code for register UI goes here


# Button to register a new customer
register_button = tk.Button(
    window,
    text="Register a new customer",
    command=register_ui,
    bd=10,
    font=("times new roman", 16),
    bg="black",
    fg="yellow",
    height=2,
    width=17,
)
register_button.place(x=100, y=520)

# Button for login
login_button = tk.Button(
    window,
    text="Login",

    bd=10,
    font=("times new roman", 16),
    bg="black",
    fg="yellow",
    height=2,
    width=17,
)
login_button.place(x=600, y=520)

# Button to exit
exit_button = tk.Button(
    window,
    text="EXIT",
    bd=10,
    command=quit,
    font=("times new roman", 16),
    bg="black",
    fg="yellow",
    height=2,
    width=17,
)
exit_button.place(x=600, y=660)

window.mainloop()
