import tkinter as tk
import webbrowser
from PIL import Image, ImageTk
import sys

parameter = sys.argv[1]  # The first argument after the script name

result = parameter.strip("[]'")
print("Parameter received:", result)
# Dictionary containing label text, corresponding YouTube links, and course links
label_links = {
    "Java": {"youtube": "https://www.youtube.com/watch?v=wIzGdDNMjCc", "course": "https://www.example.com/java_course"},
    "PHP": {"youtube": "https://www.youtube.com/watch?v=OK_JCtrrv-c", "course": "https://www.example.com/php_course"},
    "Machine Learning": {"youtube": "https://www.youtube.com/watch?v=ukzFI9rgwfU", "course": "https://www.example.com/ml_course"},
    "Tkinter": {"youtube": "https://www.youtube.com/watch?v=YXPyB4XeYLA", "course": "https://www.example.com/tkinter_course"}
}

def open_youtube_link(label_text):
    # Open the YouTube link associated with the clicked label in a web browser
    webbrowser.open(label_links[label_text]["youtube"])

def open_course_link(label_text):
    # Open the course link associated with the clicked label in a web browser
    webbrowser.open(label_links[label_text]["course"])

def main():
    # Create the main window
    root = tk.Tk()
    root.title("Course Details")

    # Create a frame to contain the boxes
    frame = tk.Frame(root)
    frame.pack(padx=20, pady=20)

    # Define icon paths
    icon_paths = {
        "Java": "java.png",
        "PHP": "php.png",
        "Machine Learning": "machinelearning.png"
    }

    # Create labels for each box with icons and clickable behavior
    for label_text, icon_path in icon_paths.items():
        # Load the icon image
        icon = Image.open(icon_path)
        icon = icon.resize((50, 50), Image.ANTIALIAS)  # Resize the icon if needed

        # Convert the image for Tkinter
        icon_tk = ImageTk.PhotoImage(icon)

        # Create a label with the icon and make it clickable
        label = tk.Label(frame, text=label_text, image=icon_tk, compound=tk.TOP, borderwidth=2, relief="groove", width=100, height=100)
        label.image = icon_tk  # Keep a reference to prevent garbage collection
        label.pack(side="left", padx=10, pady=10)

        # Bind left mouse click to open YouTube link
        label.bind("<Button-1>", lambda event, text=label_text: open_youtube_link(text))

        # Bind right mouse click to open course link
        label.bind("<Button-3>", lambda event, text=label_text: open_course_link(text))

    # Run the application
    root.mainloop()

if __name__ == "__main__":
    main()
