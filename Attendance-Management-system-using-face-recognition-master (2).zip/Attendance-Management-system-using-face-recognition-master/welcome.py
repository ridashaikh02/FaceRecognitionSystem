import tkinter as tk
from tkinter import ttk
from tkinter import *
import os, cv2
import shutil
import csv
import numpy as np
from PIL import ImageTk, Image
import sys




def set_background_image(window, image_path):
    # Open the image using PIL
    pil_image = Image.open(image_path)
    # Resize the image to fit the window
    pil_image = pil_image.resize((1280, 720), Image.ANTIALIAS)

    # Convert PIL image to PhotoImage
    tk_image = ImageTk.PhotoImage(pil_image)

    # Create a label to display the image
    bg_label = tk.Label(window, image=tk_image)
    bg_label.image = tk_image
    bg_label.place(relwidth=1, relheight=1)
    # Raise the label to the bottom of the stacking order
    bg_label.lower()

window = Tk()
window.title("Face recognizer")
window.geometry("1280x720")

# Set background image
set_background_image(window,
                     "G:/Code 23-24/Mrunal/dd/Attendance-Management-system-using-face-recognition-master/whitebg.jpg")

parameter = sys.argv[1]  # The first argument after the script name
print("Parameter received:", parameter)
lbl1 = tk.Label(
        window,
        text="Welcome "+parameter,
        width=50,
        height=2,
        bg="black",
        fg="yellow",
        bd=1,
        relief=RIDGE,
        font=("times new roman", 12),
    )
lbl1.place(x=250, y=270)
lbl2 = tk.Label(
        window,
        text="Yo have Selected Course",
        width=50,
        height=2,
        bg="black",
        fg="yellow",
        bd=1,
        relief=RIDGE,
        font=("times new roman", 12),
    )
lbl2.place(x=350, y=370)
window.mainloop()
