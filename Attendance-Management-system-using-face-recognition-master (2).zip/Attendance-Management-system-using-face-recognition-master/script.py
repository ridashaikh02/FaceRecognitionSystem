from flask import Flask, render_template, request
import os

app = Flask(__name__)

# Define a route to render the HTML page
@app.route('/')
def index():
    return render_template('home.html')

# Define a route to handle the request to execute the Python script
@app.route('/execute_py_script')
def execute_py_script():
    parameter_value = request.args.get('parameter')

    # Now you can use the parameter value as needed
    # For example, you can print it
    return "Python script executed with parameter: " + parameter_value

    # return result

if __name__ == '__main__':
    app.run(debug=True)
