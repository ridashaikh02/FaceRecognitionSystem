from flask import Flask, render_template, request

app = Flask(__name__)

# Define a route to render the HTML page
@app.route('/')
def index():
    return render_template('form.html')

# Define a route to handle form submission
@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Get data from the form
        data_from_form = request.form['data']

        # Call a Python function with the data
        processed_data = process_data(data_from_form)

        # Return the processed data
        return processed_data

# Example Python function to process data
def process_data(data):
    # Do some processing here, for example, just return the data with some additional text
    return "Data received: " + data

if __name__ == '__main__':
    app.run(debug=True)
